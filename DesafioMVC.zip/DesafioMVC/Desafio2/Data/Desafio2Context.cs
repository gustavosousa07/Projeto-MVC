﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Desafio2.Models;

namespace Desafio2.Models
{
    public class Desafio2Context : DbContext
    {
        public Desafio2Context (DbContextOptions<Desafio2Context> options)
            : base(options)
        {
        }

        public DbSet<Desafio2.Models.Aluno> Aluno { get; set; }

        public DbSet<Desafio2.Models.Professor> Professor { get; set; }
    }
}
