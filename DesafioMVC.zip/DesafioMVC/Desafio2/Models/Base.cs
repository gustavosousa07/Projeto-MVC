﻿namespace Desafio2.Models
{
    public class Base
    {
        public int id { get; set; }
    }
}