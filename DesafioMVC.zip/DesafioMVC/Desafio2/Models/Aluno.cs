﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Desafio2.Models
{
    public class Aluno : Base
    {
        public String nome { get; set; }
        public String rm { get; set; }
        public String telefone { get; set; }
        public String email { get; set; }
        public String endereco{ get; set; }
        public DateTime DataNasc{ get; set; }
        
    }
}
